package com.cg.dardenrestapiwebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DardenRestApiWebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
